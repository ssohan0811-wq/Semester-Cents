/* Semester Cents AI copilot
   Depends on these from the main app script: $, esc, fmt, ymd, cur, monthKey,
   monthTx, totals, state, save, render, EXP, INC.
   The main script is wrapped in (function(){ ... })(), so paste this code
   INSIDE that wrapper, just before the line:
   setType("expense"); resetForm(); initStorage();
   (and remove the initAI() call at the bottom of this file if that line
   already calls it). */
/* ---------- AI copilot ---------- */
const KEY_LS="semester-cents-api-key";
const MODEL="claude-haiku-5-5";
const CHIPS=["How am I doing this month?","Where can I cut back?","Can I afford a $50 night out this weekend?","How much have I spent on food?"];
let sampleFn=null, apiKey="", chatHist=[], busy=false;

function showAI(){
  const ready=!!sampleFn || !!apiKey;
  $("keybox").hidden=ready; $("chatArea").hidden=!ready;
  $("keyRemove").hidden=!apiKey || !!sampleFn;
  $("aiMode").textContent=sampleFn ? "Powered by Claude." : "Using your API key.";
  if(ready && !$("chat").children.length) addMsg("ai","Hi! I can see your transactions and budgets. Ask how your month is going, or tell me what you spent and I'll log it.");
}
async function initAI(){
  try{ apiKey=localStorage.getItem(KEY_LS)||""; }catch(e){}
  $("chips").innerHTML=CHIPS.map(c=>'<button type="button">'+esc(c)+'</button>').join("");
  if(!(window.claude && window.claude.use)){ showAI(); return; }
  try{ const s=await claude.use("sample"); if(s) sampleFn=s; }catch(e){}
  showAI();
}
function addMsg(cls,text){
  const d=document.createElement("div"); d.className="msg "+cls; d.textContent=text;
  $("chat").appendChild(d); $("chat").scrollTop=$("chat").scrollHeight; return d;
}
function aiContext(){
  const list=monthTx(); const {inc,out,byCat}=totals(list); const months={};
  for(const t of state.tx){ const k=t.date.slice(0,7); const m=months[k]||(months[k]={income:0,spent:0}); if(t.type==="income") m.income+=t.amount; else m.spent+=t.amount; }
  const r2=n=>Math.round(n*100)/100;
  return {
    today:ymd(new Date()), viewingMonth:monthKey(), daysInMonth:new Date(cur.y,cur.m+1,0).getDate(),
    incomeThisMonth:r2(inc), spentThisMonth:r2(out),
    spentByCategory:Object.fromEntries(Object.entries(byCat).map(([k,v])=>[k,r2(v)])),
    monthlyBudgets:state.budgets,
    recentMonths:Object.keys(months).sort().slice(-6).map(k=>({month:k,income:r2(months[k].income),spent:r2(months[k].spent)})),
    transactionsThisMonth:list.slice().sort((a,b)=>a.date.localeCompare(b.date)).slice(-200).map(t=>[t.date,t.type==="income"?"in":"out",t.cat,t.amount,t.note||""])
  };
}
function systemPrompt(){
  return "You are the budgeting copilot inside Semester Cents, a personal finance tracker for college students. "+
  "You can see the user's data below (amounts in USD; transactions are [date, in/out, category, amount, note]).\n\n"+
  "Rules:\n"+
  "- Answer from the data. Be specific with numbers, warm, practical and short (under 120 words). Plain text only, no markdown; use '-' lines for lists.\n"+
  "- You are not a licensed financial advisor. Don't recommend specific investments, loans or tax moves; point to the campus financial aid office or an advisor for those.\n"+
  "- If the user describes money they spent or received (e.g. 'spent 12 on chipotle yesterday', 'got paid 300 friday'), put each item in \"add\" so the app can offer to log it. Resolve relative dates against today. Pick the closest category from the lists. Never invent items they didn't describe.\n"+
  "- Expense categories: "+EXP.join(", ")+". Income categories: "+INC.join(", ")+".\n\n"+
  "Respond with ONLY a JSON object and nothing else, no code fences: "+
  '{"reply": "your message", "add": [{"type": "expense" or "income", "amount": number, "cat": "category", "date": "YYYY-MM-DD", "note": "short description"}]}. Use an empty add list when nothing should be logged.\n\n'+
  "DATA:\n"+JSON.stringify(aiContext());
}
async function callModel(system,messages){
  if(sampleFn){
    const msgs=messages.slice(); msgs[0]={role:"user",content:system+"\n\n---\n\n"+msgs[0].content};
    const r=await sampleFn(msgs,{modelTier:"quick",cache:false}); return r.text||"";
  }
  const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",
    headers:{"content-type":"application/json","x-api-key":apiKey,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},
    body:JSON.stringify({model:MODEL,max_tokens:800,system,messages})});
  if(!res.ok){ const e=new Error("HTTP "+res.status); e.status=res.status; throw e; }
  const data=await res.json();
  return (data.content||[]).filter(b=>b.type==="text").map(b=>b.text).join("");
}
function parseReply(text){
  const a=text.indexOf("{"), b=text.lastIndexOf("}");
  if(a>=0 && b>a){ try{ const o=JSON.parse(text.slice(a,b+1)); if(typeof o.reply==="string") return {reply:o.reply, add:Array.isArray(o.add)?o.add:[]}; }catch(_){} }
  return {reply:text.trim(), add:[]};
}
function cleanAdds(arr){
  return arr.map(x=>{
    const type=x && x.type==="income"?"income":"expense";
    const amount=Math.round(parseFloat(x && x.amount)*100)/100;
    const cats=type==="income"?INC:EXP;
    const cat=cats.includes(x.cat)?x.cat:(type==="income"?"Other income":"Other");
    const date=/^\d{4}-\d{2}-\d{2}$/.test(x.date)?x.date:ymd(new Date());
    return {type,amount,cat,date,note:String(x.note||"").slice(0,80)};
  }).filter(t=>t.amount>0 && t.amount<1e7).slice(0,20);
}
function proposeAdds(items){
  const box=document.createElement("div"); box.className="propose";
  const head=document.createElement("div"); head.textContent=items.length===1?"Add this transaction?":"Add these "+items.length+" transactions?";
  const ul=document.createElement("ul");
  for(const t of items){
    const li=document.createElement("li");
    const d=new Date(t.date+"T12:00:00").toLocaleDateString(undefined,{month:"short",day:"numeric"});
    li.textContent=(t.type==="income"?"+":"−")+fmt.format(t.amount)+" "+t.cat+(t.note?" ("+t.note+")":"")+", "+d;
    ul.appendChild(li);
  }
  const row=document.createElement("div"); row.className="row";
  const yes=document.createElement("button"); yes.type="button"; yes.className="btn"; yes.textContent="Add";
  const no=document.createElement("button"); no.type="button"; no.className="btn ghost"; no.textContent="Dismiss";
  yes.onclick=()=>{
    items.forEach((t,i)=>state.tx.push(Object.assign({id:Date.now().toString(36)+i+Math.random().toString(36).slice(2,6),created:Date.now()+i},t)));
    save(); render();
    box.replaceChildren(document.createTextNode("Added "+items.length+(items.length===1?" transaction.":" transactions.")));
  };
  no.onclick=()=>box.replaceChildren(document.createTextNode("Dismissed. Nothing was added."));
  row.append(yes,no); box.append(head,ul,row);
  $("chat").appendChild(box); $("chat").scrollTop=$("chat").scrollHeight;
}
function aiError(e){
  const s=e && e.status, c=e && e.code;
  if(s===401) return "That API key was rejected. Remove it below and save a valid one.";
  if(s===429 || c==="rate_limited") return "Too many requests right now. Wait a moment and try again.";
  if(c==="not_granted") return "The copilot needs your permission to use Claude. Send your message again and allow it.";
  if(s===529 || s>=500) return "The AI service is busy. Try again in a minute.";
  return "Couldn't reach the copilot. Check your connection and try again.";
}
async function ask(text){
  text=(text||"").trim(); if(!text || busy) return;
  busy=true; $("askBtn").disabled=true; $("askInput").value="";
  addMsg("me",text);
  const wait=addMsg("ai wait","Thinking…");
  chatHist.push({role:"user",content:text});
  const msgs=chatHist.slice(-12); if(msgs[0].role!=="user") msgs.shift();
  try{
    const {reply,add}=parseReply(await callModel(systemPrompt(),msgs));
    wait.remove();
    addMsg("ai",reply||"I didn't catch that. Try asking another way.");
    chatHist.push({role:"assistant",content:JSON.stringify({reply,add})});
    const items=cleanAdds(add); if(items.length) proposeAdds(items);
  }catch(e){
    wait.remove(); chatHist.pop(); addMsg("err",aiError(e));
  }finally{ busy=false; $("askBtn").disabled=false; $("askInput").focus(); }
}
$("askBtn").onclick=()=>ask($("askInput").value);
$("askInput").addEventListener("keydown",e=>{ if(e.key==="Enter"){ e.preventDefault(); ask($("askInput").value); } });
$("chips").addEventListener("click",e=>{ const b=e.target.closest("button"); if(b) ask(b.textContent); });
$("keySave").onclick=()=>{
  const k=$("keyInput").value.trim();
  if(!k.startsWith("sk-")){ $("keyErr").textContent="That doesn't look like an Anthropic API key. It should start with sk-ant-."; return; }
  apiKey=k; $("keyErr").textContent=""; $("keyInput").value="";
  try{ localStorage.setItem(KEY_LS,k); }catch(e){}
  showAI();
};
$("keyInput").addEventListener("keydown",e=>{ if(e.key==="Enter") $("keySave").click(); });
$("keyRemove").onclick=()=>{ apiKey=""; try{ localStorage.removeItem(KEY_LS); }catch(e){} showAI(); };

initAI();
